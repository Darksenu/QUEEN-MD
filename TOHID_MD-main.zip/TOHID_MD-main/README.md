---------

### <br>  ❖ TOHID_MD ❖
🔰 **`THE WORLD BEST WHATSAPP BOT CREATED BY TOHID KHAN`** 🔰

----------

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

-------

 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=00008B&center=true&vCenter=true&multiline=false&lines=`TOHID+_+MD+WHATSAPP+BOT`" alt="">

------------

<img align="center" height="auto"
src="https://cardivo.vercel.app/api?name=TOHID%20_%20MD%20V2&description=🥂THE%20WORLD%20BEST%20WHATSAPP%20BOT%★%20CREATED%20BY%20TOHID%20KHAN%20KING%20OF%20KINGS%20OWNER%20TOHID%20KHAN%20AND%20SAHIB%20KHAN♥️&image=https://telegra.ph/file/042cd0b6121a7923fd5d2.jpg?v=4&backgroundColor=%23ecf0f1&github=Tohidkhan6332&pattern=leaf&colorPattern=%23eaeaea"/>

<br>

`❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀`

<br>

--------

<p align="center">
<a href="https://github.com/Tohidkhan6332/"><img title="Followers" src="https://img.shields.io/github/followers/Tohidkhan6332?color=blue&style=flat-square"></a>
<a href="https://github.com/Tohidkhan6332/TOHID_MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Tohidkhan6332/TOHID_MD?color=blue&style=flat-square"></a>
<a href="https://github.com/Tohidkhan6332/TOHID_MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Tohidkhan6332/TOHID_MD?color=blue&style=flat-square"></a>
<a href="https://github.com/Tohidkhan6332/TOHID_MD/"><img title="Size" src="https://img.shields.io/github/repo-size/Tohidkhan6332/TOHID_MD?style=flat-square&color=blue"></a>
<a href="https://github.com/Tohidkhan6332/TOHID_MD/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

-----------
----------

<div align="center"><br> <img src="https://profile-counter.glitch.me/TOHID_MD/count.svg" /><br>TOHID_MD-V2</div>

------------

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

--------------

`❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀`

----------------

![repo views](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/Tohidkhan6332/TOHID_MD&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false)


![forks](https://img.shields.io/github/forks/Tohidkhan6332/TOHID_MD?label=Forks&style=social)


![stars](https://img.shields.io/github/stars/Tohidkhan6332/TOHID_MD?style=social)


[![FORK TOHID_MD](https://img.shields.io/badge/FORK%20-TOHID%20_%20MD-white)](https://github.com/Tohidkhan6332/TOHID_MD/fork)

`⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛`

---------------

</a>
</p>

-----------------

🥂 `THIS BOT IS CREATED TO DOWNLOAD'S AND FIND VARIOUS TYPES THINGS QUICKLY **EXAMPLE** LOGO, PHOTO, STICKERS, VIDEOS, MOVIES, ADULT, AND MANY MORE FEATURES BY USING THIS BOT™ THIS BOT IS CREATED TO USING` 🥂 **[Baileys](https://github.com/WhiskeySockets/Baileys)**

------------------

`⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛`

-----------------

### <br> ❖ FOR SUPPORT ❖

**`➩ HII DEARS FRIENDS IF YOU WANT ANY HELP SO YOU CAN CONTACT↘︎ WITH ME WIA WHATSAPP ITS ME TOHID✠KHAN࿐➺`**

-------

<p align="center">
  <a href="https://wa.me/+917849917350?text=*ʜɪɪ+ᴛᴏʜɪᴅ+ᴋʜᴀɴ+ɪ+ɴᴇᴇᴅ+ʜᴇʟᴘ!.+ɪ+ᴍᴇssᴀɢᴇᴅ+ʏᴏᴜ+ғʀᴏᴍ+ᴛᴏʜɪᴅ_ᴍᴅ+ʀᴇᴘᴏ!!*" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/ Whatsapp -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

-----------    

`✠ IF YOU WANT MORE ABOUT TOHID_MD WHATSAPP BOT :-NEW UPDATED NEW CMDS SO JOIN OUR WHATSAPP GROUP FOR MORE INFORMATION CLICK THIS RED BUTTON 🔳 AND JOIN THE GROUP ✠`

---------

<a href="https://whatsapp.com/channel/0029VaGyP933bbVC7G0x0i2T"><img src="https://img.shields.io/badge/%F0%9F%8E%89%20ᴊᴏɪɴ%20ᴏᴜʀ%20ᴡʜᴀᴛsᴀᴘᴘ%20ᴄʜᴀɴɴᴇʟ-red" alt="🔰 ᴊᴏɪɴ ᴍʏ ᴡʜᴀᴛsᴀᴘᴘ ɢʀᴏᴜᴘ ғᴏʀ ᴜᴘᴅᴀᴛᴇ 🔰" width="300"></a>

-----------

`✠ IF YOU WANT MORE ABOUT TOHID_MD WHATSAPP BOT :-NEW UPDATED NEW CMDS SO SUBSCRIBE OUR YOUTUBE CHANNEL FOR MORE INFORMATION CLICK THIS BLUE BUTTON 🔳 AND JOIN THE YOUTUBE CHANNEL ✠`

----------

<a href="https://youtube.com/@tohidkhan_6332?si=f1hxIhv2ijpalqGl"><img src="https://img.shields.io/badge/%F0%9F%8E%89%20ᴊᴏɪɴ%20ᴏᴜʀ%20ʏᴏᴜᴛᴜʙᴇ%20ᴄʜᴀɴɴᴇʟ-blue" alt="🔰 ᴊᴏɪɴ ᴍʏ ʏᴏᴜᴛᴜʙᴇ ғᴏʀ ᴜᴘᴅᴀᴛᴇ 🔰" width="300"></a>

--------------

`✠`✠`✠`✠`✠`✠`✠`✠`✠`✠`✠`✠`✠`✠`✠`✠

### <br> ❖ DEPLOY AND SESSION METHOD ❖

<br>

`✠ HOW TO DEPLOY TOHID_MD ON HEROKU WATCH VIDEO AND SUPPORT OUR YOUTUBE CHANNEL ✠`

-------------

<p align="center">
   <a href="https://youtube.com/@tohidkhan_6332?si=f1hxIhv2ijpalqGl"><img src="https://i.ibb.co/71mYRh4/116-1161192-podcast-subscribe-listen-button-youtube-sign-hd-png.png" alt="Watch tutorial on YouTube" border="0"  width="105">
    </a>
</p>

---------------


### <br>    ❖ SESSION_ID ❖


`✠ IF YOU DON'T HAVE YOUR SESSION_ID SO U CAN GET IT CLICK ON SESSION_ID BUTTON AND PASTE YOUR NUMBER With COUNTRY CODE EXAMPLE:+9178499XXXX THEN YOU CAN GET YOUR SESSION_ID ✠`

----------

<p align="center">
<a href="https://tohid-md-web-pair-qr.onrender.com"><img height= "35" title="Author" src="https://img.shields.io/badge/GET SESSION ID-1:-black?style=for-the-badge&logo=render"></a>
<p/>

----------

----------

<p align="center">
<a href="https://tohid-md-web-pair-qr.onrender.com"><img height= "35" title="Author" src="https://img.shields.io/badge/GET SESSION ID-2:-black?style=for-the-badge&logo=render"></a>
<p/>

----------
 
### <br>   ❖ DEPLOY_HEROKU ❖

`✠ IF YOU WANT TO DEPLOY TOHID_MD BOT ON HEROKU SO FIRST GET YOUR SESSION_ID THEN CLICK THIS BLUE BUTTON [DEPLOY TO HEROKU] THEN YOU CAN ENJOY THIS BOT ✠`

------------
 
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new-app?template=https://github.com/Tohidkhan6332/TOHID_MD)

----------

### <br>    ❖ DEPLOY_REPLIT ❖

`✠ IF U HAVE YOUR REPLIT ACCOUNT SO YOU CAN EASY DEPLOY TOHID_MD ON REPLIT CLICK BLACK BUTTON [DEPLOY TO REPLIT] AND FIND CONFIG.JSON FILE THEN PASTE YOUR SESSION AND MONGODB KEY THEN RUN CODE AND ENJOY BOT ✠`

-------------

<p align="left"><a href="https://repl.it/github/Tohidkhan6332/TOHID_MD"> <img src='https://img.shields.io/badge/-REPLIT-orange?style=for-the-badge&logo=replit&logoColor=white'/></a>

--------------

### <br>   ❖ DEPLOY_KOYEB ❖

`✠ IF YOU HAVE YOUR KOYEB ACCOUNT SO YOU CAN DEPLOY TOHID_MD ON KOYEB WITH EASY SETUP NOTE:-MAYBE SOME PROBLEM TO DEPLOY ON KOYEB I ILL FIX SOON ✠`

---------

<a href='https://app.koyeb.com/auth/signin' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-KOYEB-blue?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

------------

### <br>  ❖ DEPLOY_RAILWAY ❖

`✠ IF YOU HAVE YOUR RAILWAY ACCOUNT SO YOU CAN DEPLOY TOHID_MD ON RAILWAY WITH EASY SETUP NOTE:-MAYBE SOME PROBLEM TO DEPLOY ON KOYEB I ILL FIX SOON ✠`

--------

<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RAILWAY-h?color=black&style=for-the-badge&logo=railway'/></a></p>

---------------

### <br> ❖ MORE DEPLOY METHOD ❖

--------
### <br>   ❖ DEPLOY_GLITCH ❖

<a href='https://glitch.com/signup' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/GLITCH-h?color=pink&style=for-the-badge&logo=glitch'/></a></p>

--------

### <br>   ❖ DEPLOY_CODESPACE ❖

<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/CODESPACE-h?color=navy&style=for-the-badge&logo=visualstudiocode'/></a></p>

--------

### <br>   ❖ DEPLOY_RENDER ❖

<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RENDER-h?color=maroon&style=for-the-badge&logo=render'/></a></p>

-----------

### <br>   ❖ DEPLOY_WORKFLOWS ❖
```
name: Node.js CI

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main

jobs:
  build:

    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm install

    - name: Start application
      run: npm start
```

-----------

`✠ HOW TO DEPLOY TOHID_MD ON WORKFLOWS FREE GITHUB WATCH VIDEO ✠`

-------------

<p align="center">
   <a href="https://youtube.com/@tohidkhan_6332?si=f1hxIhv2ijpalqGl"><img src="https://i.ibb.co/71mYRh4/116-1161192-podcast-subscribe-listen-button-youtube-sign-hd-png.png" alt="Watch tutorial on YouTube" border="0"  width="105">
    </a>
</p>

-------------

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

------------

`⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛`

---------

![IMG-20240330-WA0000](https://telegra.ph/file/042cd0b6121a7923fd5d2.jpg)

-------------------

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

-----------

***⚠️THANKS FOR USING TOHID_MD WHATSAPP BOT IF U HAVE ANY PROBLEM YOU CAN CONTECT ME NOTE TOHID_MD A ANTIBAN WHATSAPP BOT BUT IF YOUR WHATSAPP ACCOUNT BANNED THEN I'M NO RESPONSE ABLE THANK YOU BY TOHID KHAN KING OF WHATSAPP♥️☣️🥂***

------------

![license](https://img.shields.io/github/license/Tohidkhan6332/TOHID_MD?color=green&label=License&style=plastic)

----------

